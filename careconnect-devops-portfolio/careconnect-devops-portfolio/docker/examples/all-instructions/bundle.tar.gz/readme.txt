extracted by ADD
